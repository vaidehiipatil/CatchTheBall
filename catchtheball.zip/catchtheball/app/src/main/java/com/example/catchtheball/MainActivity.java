package com.example.catchtheball;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private LinearLayout startScreen;
    private GameView gameView;
    private Button startButton, restartButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startScreen   = findViewById(R.id.startScreen);
        gameView      = findViewById(R.id.gameView);
        startButton   = findViewById(R.id.startButton);
        restartButton = findViewById(R.id.restartButton);

        startButton.setOnClickListener(v -> {
            startScreen.setVisibility(View.GONE);
            gameView.setVisibility(View.VISIBLE);
            gameView.startGame();
        });

        restartButton.setOnClickListener(v -> {
            restartButton.setVisibility(View.GONE);
            gameView.restartGame();
        });
    }

    /** Called by GameView when a miss occurs */
    public void showRestartButton() {
        runOnUiThread(() -> restartButton.setVisibility(View.VISIBLE));
    }
}
