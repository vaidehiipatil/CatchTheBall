package com.example.catchtheball;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class GameView extends View {
    private final Paint paint = new Paint();
    private final Paint bgPaint = new Paint();
    private final Random random = new Random();
    private final Handler handler = new Handler();

    private float ballX, ballY;
    private static final float BALL_RADIUS = 40f;

    private float basketX, basketY;
    private static final float BASKET_WIDTH = 250f;
    private static final float BASKET_HEIGHT = 50f;

    private int score = 0;
    private int highScore = 0;
    private float ballSpeed = 15f;
    private static final float SPEED_INCREMENT = 2f;

    private boolean isStarted = false;
    private boolean isGameOver = false;

    private SharedPreferences prefs;

    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        // Load high score
        prefs     = context.getSharedPreferences("game_prefs", Context.MODE_PRIVATE);
        highScore = prefs.getInt("high_score", 0);
        setFocusable(true);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        // Create a vertical gradient once we know height
        bgPaint.setShader(new LinearGradient(
                0, 0, 0, h,
                Color.parseColor("#2196F3"),  // top blue
                Color.parseColor("#4CAF50"),  // bottom green
                Shader.TileMode.CLAMP));
        super.onSizeChanged(w, h, oldw, oldh);
    }

    /** Call to begin the game */
    public void startGame() {
        isStarted  = true;
        isGameOver = false;
        score      = 0;
        ballSpeed  = 15f;
        highScore  = prefs.getInt("high_score", 0);
        resetPositions();
        invalidate();
    }

    /** Call to restart after Game Over */
    public void restartGame() {
        startGame();
    }

    private void resetPositions() {
        basketY = getHeight() - 200f;
        basketX = getWidth()/2f - BASKET_WIDTH/2f;
        ballY   = 0;
        ballX   = random.nextInt(Math.max(1, (int)(getWidth() - BALL_RADIUS*2))) + BALL_RADIUS;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!isStarted) return;

        // 1) Clear background
        canvas.drawColor(Color.WHITE);

        // 2) Draw Ball
        paint.setColor(Color.BLUE);
        canvas.drawCircle(ballX, ballY, BALL_RADIUS, paint);

        // 3) Draw Basket (rounded + shadow)
        float corner = 30f, stroke = 6f;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#32CD32"));
        canvas.drawRoundRect(
                basketX + stroke/2, basketY + stroke/2,
                basketX + BASKET_WIDTH - stroke/2, basketY + BASKET_HEIGHT - stroke/2,
                corner, corner, paint
        );

        // 4) Game logic: move ball, catch or miss
        if (!isGameOver) {
            ballY += ballSpeed;
            if (ballY + BALL_RADIUS >= basketY
                    && ballX >= basketX
                    && ballX <= basketX + BASKET_WIDTH) {

                // caught
                score++;
                ballSpeed = 15f + score * SPEED_INCREMENT;
                resetPositions();

            } else if (ballY > getHeight()) {
                // missed → game over
                isGameOver = true;
                // update high score
                if (score > highScore) {
                    prefs.edit().putInt("high_score", score).apply();
                    highScore = score;
                }
                // show restart button
                if (getContext() instanceof MainActivity) {
                    ((MainActivity)getContext()).showRestartButton();
                }
            }
        }

        // 5) Draw live Score & High Score (only while playing)
        if (!isGameOver) {
            paint.setColor(Color.BLACK);
            paint.setTextSize(48f);
            paint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText("Score: " + score, 50f, 80f, paint);
            canvas.drawText("High Score: " + highScore, 50f, 140f, paint);
        }

        // 6) If Game Over, draw dark overlay + centered texts
        if (isGameOver) {
            // overlay
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(180, 0, 0, 0));
            canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
            // “GAME OVER”
            paint.setColor(Color.RED);
            paint.setTextSize(96f);
            paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("GAME OVER", getWidth()/2f, getHeight()/2f - 60f, paint);
            // final scores
            paint.setColor(Color.WHITE);
            paint.setTextSize(60f);
            canvas.drawText("Score: " + score, getWidth()/2f, getHeight()/2f + 20f, paint);
            canvas.drawText("High Score: " + highScore, getWidth()/2f, getHeight()/2f + 100f, paint);
        }

        // 7) Schedule next frame if still playing
        if (!isGameOver) {
            handler.postDelayed(this::invalidate, 17);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (isStarted && !isGameOver &&
                (event.getAction() == MotionEvent.ACTION_DOWN ||
                        event.getAction() == MotionEvent.ACTION_MOVE)) {

            basketX = event.getX() - BASKET_WIDTH/2f;
            basketX = Math.max(0, Math.min(basketX, getWidth() - BASKET_WIDTH));
            invalidate();
        }
        return true;
    }
}
